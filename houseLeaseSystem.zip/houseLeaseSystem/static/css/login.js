function getCookie(name) {
    var r = document.cookie.match("\\b" + name + "=([^;]*)\\b");
    return r ? r[1] : undefined;
}

$(document).ready(function() {
    $("#uphone").focus(function(){
        $("#uphone").hide();
    });
    $("#upwd").focus(function(){
        $("#upwd-err").hide();
    });
    $(".form-login").submit(function(e){
        e.preventDefault();
        mobile = $("#uphone").val();
        passwd = $("#upwd").val();
        if (!mobile) {
            $("#uphone-err span").html("请填写正确的手机号！");
            $("#uphone-err").show();
            return;
        } 
        if (!passwd) {
            $("#upwd-err span").html("请填写密码!");
            $("#upwd-err").show();
            return;
        }
    });
})