from django.conf.urls import url
from . import views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    url(r'^generate_contract', views.generate_contract_api),
    url(r'^order_house_html', views.order_house_html_api),
    url(r'^order_house', views.order_house_api),
    url(r'^attention_house', views.attention_house_api),
    url(r'^searchMore', views.search_more_api),
    url(r'^get_house_type', views.get_house_type_api),
    url(r'^change_msg', views.change_msg),
    url(r'^change_pwd', views.change_pwd),
    url(r'^change_header', views.change_header),
    url(r'^get_contract', views.contract_view),
    # url(r'^get_contract', views.get_contract),
    url(r'^login', views.login_view),
    url(r'^userinfo', views.userinfo_view),
    url(r'^register', views.register_view),
    url(r'^room_add', views.room_add_view),
    url(r'^search', views.search_view),
    url(r'^orderresult', views.orderresult_view),
    url(r'^logout', views.logout_view),
    url(r'^delfollow', views.delfollow_view),
    url(r'^contract', views.contract_view),
    url(r'^person', views.person_view),
    url(r'^myhouse', views.myhouse_view),
    url(r'^followhouse', views.followhouse_view),
    url(r'^comments', views.comments),
    url(r'^', views.index_view, name='index'),
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)

# urlpatterns = [
#     path('dashboard/', views.dashboard, name='dashboard'),
# ]
