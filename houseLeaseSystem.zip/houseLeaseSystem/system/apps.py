from django.apps import AppConfig


class IndexConfig(AppConfig):
    name = 'system'
    verbose_name = '租房管理系统'
