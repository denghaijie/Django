from django.contrib import admin
from .models import *

# Register your models here.注册数据模型
class TUserAdmin(admin.ModelAdmin):
    '''设置列表可显示的字段'''
    list_display = ['id','uname','uemail','role','usex','uage','uphone','header']
    #过滤筛选
    list_filter = ['role']
    search_fields = ['uname']
    list_per_page = 6

class THouseAdmin(admin.ModelAdmin):
    '''设置列表可显示的字段'''
    list_display = ['id','hname','address','house_desc','price','house_size','uid','category']
    # '''每页显示条目数'''
    # list_per_page = 3
    # 过滤筛选
    list_filter = ['category']
    search_fields = ['hname']
    list_per_page = 6

class TContractAdmin(admin.ModelAdmin):
    '''设置列表可显示的字段'''
    list_display = ['id','hname','start_time','end_time','price','lid','tid']
    list_filter = ['hname']
    search_fields = ['price']
    # '''每页显示条目数'''
    list_per_page = 6

class TCategoryAdmin(admin.ModelAdmin):
    '''设置列表可显示的字段'''
    list_display = ['id','cname','descs']
    list_filter = ['cname']

class TFollowAdmin(admin.ModelAdmin):
    '''设置列表可显示的字段'''
    list_display = ['id','uid','uname','hname']
    list_filter = ['hname']
    search_fields = ['uname']
    list_per_page = 6

class TCommentsAdmin(admin.ModelAdmin):
    '''设置列表可显示的字段'''
    list_display = ['id','username','hname','comment']
    list_filter = ['hname']
    search_fields = ['username']
    list_per_page = 6

admin.site.register(TUser,TUserAdmin)
admin.site.register(THouse,THouseAdmin)
admin.site.register(TContract,TContractAdmin)
admin.site.register(TCategory,TCategoryAdmin)
admin.site.register(TFollow,TFollowAdmin)
admin.site.register(TComments,TCommentsAdmin)
admin.site.site_header = '租房管理系统后台管理'
admin.site.site_title = '租房管理系统后台管理'
