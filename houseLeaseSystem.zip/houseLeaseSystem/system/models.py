from djongo import models
from django.core.files.storage import FileSystemStorage
fs = FileSystemStorage(location='/media/avatars')

class BaseModel(models.Model):
    create_time = models.DateTimeField(auto_now_add=True,null=True)
    update_time = models.DateTimeField(auto_now=True,null=True)

    class Meta:
        abstract = True

class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(BaseModel,models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class TAdmin(models.Model):
    adminname = models.CharField(max_length=50, blank=True, null=True)
    adminpwd = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't_admin'


class TCategory(BaseModel,models.Model):
    # cname = models.ForeignKey('THouse', models.DO_NOTHING, to_field='category', blank=True, null=True, verbose_name='类型名称')
    cname = models.CharField(max_length=50, blank=True, null=True, verbose_name='类型名称')
    descs = models.CharField(max_length=50, blank=True, null=True, verbose_name='简介')

    class Meta:
        managed = True
        db_table = 't_category'
        verbose_name_plural = '房屋类型管理'

    def __str__(self):
        return self.cname


class TContract(BaseModel,models.Model):
    start_time = models.DateField(blank=True, null=True, verbose_name='开始日期')
    end_time = models.DateField(blank=True, null=True, verbose_name='结束日期')
    hname = models.CharField(max_length=50, blank=True, null=True, verbose_name='房屋名称')
    price = models.IntegerField(blank=True, null=True, verbose_name='租金')
    lid = models.IntegerField(blank=True, null=True, verbose_name='房东id')
    tid = models.IntegerField(blank=True, null=True, verbose_name='租户id')
    tphone = models.CharField(max_length=11,blank=True, null=True, verbose_name='租户手机号')
    lphone = models.CharField(max_length=11, blank=True, null=True, verbose_name='房东手机号')

    class Meta:
        managed = True
        db_table = 't_contract'
        verbose_name_plural = '合同管理'

    def __str__(self):
        return str(self.start_time)



class THouse(BaseModel,models.Model):
    hname = models.CharField(max_length=50, blank=True, null=True, verbose_name='房屋名称')
    address = models.CharField(max_length=50, blank=True, null=True, verbose_name='房屋地址')
    house_desc = models.CharField(max_length=50, blank=True, null=True, verbose_name='房屋户型')
    price = models.IntegerField(blank=True, null=True, verbose_name='房屋租金')
    house_size = models.IntegerField(blank=True, null=True, verbose_name='房屋面积')
    # uid = models.ForeignKey('TUser', models.DO_NOTHING, db_column='uid', blank=True, null=True, verbose_name='房东名称')
    uid = models.CharField(max_length=50, blank=True, null=True, verbose_name='房东名称')
    image = models.ImageField(null=True, verbose_name='房屋图片', upload_to='image/')
    status = models.IntegerField(default=1, verbose_name='房屋状态') #1为待租，2为已租
    category = models.CharField(max_length=50, verbose_name='房屋类型')
    class Meta:
        managed = True
        db_table = 't_house'
        verbose_name_plural = '房屋管理'

    def __str__(self):
        return self.hname


class TUser(BaseModel,models.Model):
    uname = models.CharField(max_length=50, blank=True, null=True, verbose_name='用户名称')
    upwd = models.CharField(max_length=20, blank=True, null=True, verbose_name='密码')
    role = models.IntegerField(default=2,blank=True, null=True, verbose_name='用户角色') #1为房东，2为租户
    uemail = models.CharField(max_length=20, blank=True, null=True, verbose_name='电子邮箱')
    usex = models.CharField(max_length=50, blank=True, null=True, verbose_name='性别')
    uage = models.CharField(max_length=20, blank=True, null=True, verbose_name='年龄')
    # status = models.IntegerField(blank=True, null=True, verbose_name='用户状态')
    uphone = models.CharField(max_length=11, verbose_name='用户手机号')
    header = models.ImageField(null=True, verbose_name='头像',upload_to='avatars/')  # 头像
    # house = models.CharField(max_length=50,blank=True, null=True, verbose_name='收藏的房源')

    class Meta:
        managed = True
        db_table = 't_user'
        verbose_name_plural = '用户管理'

    def __str__(self):
        return self.uname

class TFollow(models.Model):
    uid = models.CharField(max_length=50, blank=True, null=True, verbose_name='用户id')
    uname = models.CharField(max_length=50, blank=True, null=True, verbose_name='用户名称')
    hname = models.CharField(max_length=50, blank=True, null=True, verbose_name='收藏的房源')
    class Meta:
        managed = True
        db_table = 't_follow'
        verbose_name_plural = "收藏管理"

    def __str__(self):
        return self.uname

class TComments(BaseModel,models.Model):
    username = models.CharField(max_length=50, blank=True, null=True, verbose_name='用户名称')
    hname = models.CharField(max_length=50, blank=True, null=True, verbose_name='房屋名称')
    comment = models.CharField(max_length=50, blank=True, null=True, verbose_name='评论内容')
    class Meta:
        managed = True
        db_table = 't_comments'
        verbose_name_plural = "评论管理"

    def __str__(self):
        return self.username

# class TRole(models.Model):
#     title = models.CharField(max_length=32, verbose_name="角色名称")
#     permissions = models.ManyToManyField(to="TPermission", blank=True, verbose_name="角色关联的权限")
#     class Meta:
#         managed = True
#         db_table = 't_role'
#         verbose_name_plural = "角色管理"
#
#     def __str__(self):
#         return self.title
#
# class TPermission(models.Model):
#     title = models.CharField(max_length=32, verbose_name="权限名称")
#     url = models.CharField(max_length=128, verbose_name="含正则的URL")
#     # method = models.CharField(max_length=12, verbose_name="请求方式")
#
#     class Meta:
#         managed = True
#         db_table = 't_permission'
#         verbose_name_plural = "权限管理"
#
#     def __str__(self):
#         return self.title
