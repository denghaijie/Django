from django.core import serializers

from django.urls import reverse
from django.shortcuts import render, HttpResponse, redirect,HttpResponseRedirect
from django.template import loader
from .models import *
import json
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage,InvalidPage
from django.conf import settings
from datetime import datetime
from django.core.files.storage import default_storage
from django.http import JsonResponse
from houseLeaseSystem.settings import MEDIA_ROOT

# Create your views here.
def logout_view(request):   #退出登录
    del request.session['uname']
    return redirect('index.html')


def index_view(request):    #系统首页
    house = THouse.objects.all()
    paginator = Paginator(house, 2)  # 按每页2条分页
    page= request.GET.get('page', 1)  # 默认跳转到第一页
    try:
        page_obj = paginator.page(page)  # 分页
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    is_paginated = True if paginator.num_pages > 1 else False
    # 获取智能页码范围，并传递给模板
    page_range = paginator.get_elided_page_range(page, on_each_side=1, on_ends=1)
    if request.session.get('uname', ''):
        uname = request.session['uname']
        paginator = Paginator(house, 2)# 按每页2条分页
        page = request.GET.get('page',1)# 默认跳转到第一页
        try:
            page_obj = paginator.page(page)  # 分页
        except PageNotAnInteger:
            page_obj = paginator.page(1)
        except EmptyPage:
            page_obj = paginator.page(paginator.num_pages)
        is_paginated = True if paginator.num_pages > 1 else False
        # 获取智能页码范围，并传递给模板
        page_range = paginator.get_elided_page_range(page, on_each_side=1, on_ends=1)
    return render(request, 'index.html', locals())

def room_add_view(request):   #发布房源及权限识别
    if request.method == 'GET':
        uname = request.session['uname']
        user = TUser.objects.filter(uname=uname)
        Urole = user.filter(role='1') #设置访问权限，当用户角色为房东时
        if Urole:
            return render(request, 'room_add.html',locals())
        else:
            return HttpResponse("<h1 aligin='center'>你当前的用户角色为租户，"
                    "无发布房源权限</h1><a href='/index.html'>返回首页</a>")
    else:
        hname = request.POST['hname']
        category = request.POST['category']
        house_desc = request.POST['house_desc']
        house_size = request.POST['house_size']
        price = request.POST['price']
        address = request.POST['address']
        image = request.POST['image']
        uid = request.POST['uid']
        house = THouse.objects.filter(hname=hname).first()
        uname = request.session['uname']
        if house:
            error = '该房屋已存在，请重试'
            return render(request, 'room_add.html', {'error': error})
        try:
            THouse.objects.create(hname=hname, category=category, house_desc=house_desc,
            house_size=house_size,price=price, address=address,image=image,uid=uid)
            return HttpResponse("<h1 aligin='center'>房源发布成功</h1>"
                                "<a href='/index'>跳转至首页</a>")
        except Exception as e:
            return HttpResponse(e)


def register_view(request):    #注册
    if request.method == 'GET':
        return render(request, 'register.html')
    else:
        uphone = request.POST['uphone']
        upwd = request.POST['upwd']
        uname = request.POST['uname']
        uemail = request.POST['uemail']
        usex = request.POST['usex']
        uage = request.POST['uage']
        role = request.POST.get('role', 2)
        user = TUser.objects.filter(uphone=uphone).first()
        if user:
            error = '该用户已存在，请重试'
            return render(request, 'register.html', {'error': error})
        try:
            TUser.objects.create(uname=uname, upwd=upwd, uemail=uemail,
                                 usex=usex,uage=uage,uphone=uphone,role=role)
            return HttpResponse("<h1 aligin='center'>注册成功</h1>""<a href='/loginapp'>前往登录</a>")
        except Exception as e:
            return HttpResponse(e)


def search_view(request):   #搜索房源
    search_item = request.GET['searchItem']#房屋名字
    house_type = request.GET['houseType']#房屋类型
    if search_item =='' and house_type =='---请选择---':
        house = THouse.objects.all()
        data = serializers.serialize('json', house)
        return HttpResponse(data)
    if search_item and house_type =='---请选择---':
        house = THouse.objects.filter(hname__icontains=search_item).all()
        data = serializers.serialize('json', house)
        return HttpResponse(data)
    if house_type and search_item =='':
        house = THouse.objects.filter(category=house_type).all()
        data = serializers.serialize('json', house)
        return HttpResponse(data)
    if search_item and house_type:
        house = THouse.objects.filter(category=house_type,hname__icontains=search_item).all()
        data = serializers.serialize('json', house)
        return HttpResponse(data)
    data = {
        'message': '没有相关搜索内容'
    }
    return HttpResponse(json.dumps(data))

def login_view(request):  #登录
    if request.method == 'GET':
        return render(request, 'loginapp.html')
    else:
        uphone = request.POST['uphone']
        upwd = request.POST['upwd']
        user = TUser.objects.filter(uphone=uphone).first()
    if user:
        # 判断密码是否正确
        if user.upwd == upwd:
            request.session['uname'] = user.uname
            request.session['id'] = user.id
            return redirect('/') #密码正确
        else:
            error = '手机号码或者密码输入有误，请重试'
            return render(request, 'loginapp.html', { 'error': error})
    else:
        error = '用户手机号码不存在，请重试'
        return render(request, 'loginapp.html', {'error': error})

def contract_view(request):   #显示合同数据
    uname = request.session['uname']
    if request.GET.get('contractId', ''):
        cid = request.GET.get('contractId')
        contract = TContract.objects.filter(id=cid).first()
        landlord = TUser.objects.filter(id=contract.lid).first()
        tenant = TUser.objects.filter(id=contract.tid).first()
        return render(request, 'contract.html', locals())
    tenant = TFollow.objects.filter(uname=uname).first()
    return render(request, 'contract.html', locals())

def orderresult_view(request):
    contract = TContract.objects.last()
    return render(request, 'orderresult.html', locals())

# def get_contract(request):    #获取合同数据
#     contract_id = request.GET.get('contractId', '')
#     if contract_id:
#         contract_data = TContract.objects.filter(id=contract_id).first()
#         if contract_data:
#             uname = request.session['uname']
#             # house_name = THouse.objects.filter(id=contract_data.hid).first()
#             tenant = TUser.objects.filter(id=contract_data.lid).first()
#             landlord = TUser.objects.filter(id=contract_data.tid).first()
#             response_data = {
#                 'contractId': contract_data.id,
#                 'start_time': contract_data.start_time,
#                 'end_time': contract_data.end_time,
#                 'hname': contract_data.hname,
#                 'price': contract_data.price,
#                 'tenant': tenant.uname,
#                 'landlord': landlord.uname,
#             }
#             template = loader.get_template('contract.html')
#             context = {'data': response_data}
#             return HttpResponse(template.render(context))
#         return HttpResponse("<h1 aligin='center'>合同不存在</h1>""<a href='/contract'>返回重新查询</a>")
#     return HttpResponse("<h1 aligin='center'>请输入正确的合同编号</h1>""<a href='/contract'>返回重新查询</a>")

def contract_view(request):  #获取查询合同数据
    uname = request.session['uname']
    uid = request.session['id']
    user = TUser.objects.filter(uname=uname)
    Urole = user.filter(role='2')  # 设置访问权限，当用户角色为租户时
    if Urole:  #获取租户的合同数据
        order = TContract.objects.filter(tid=uid).all()
        return render(request, 'contract.html', locals())
    else:   #获取房东的合同数据
        order = TContract.objects.filter(lid=uid).all()
        return render(request, 'contract.html', locals())

def userinfo_view(request):   #展示个人信息
    uname = request.session['uname']
    tenant = TFollow.objects.filter(uname=uname).first()
    userInfo = TUser.objects.filter(uname=uname).first()
    return render(request, 'userinfo.html', locals())

def person_view(request):  #设置菜单
    uname = request.session['uname']
    tenant = TFollow.objects.filter(uname=uname).first()
    return render(request, 'person.html', locals())


# def change_name(request):   #修改用户名称
#     new_name = request.GET.get('newName', '')
#     if new_name:
#         user_name = request.session['uname']
#         user_id = request.session['id']
#         user = TUser.objects.filter(uname=user_name).update(uname=new_name)
#         followuser = TFollow.objects.filter(uid=user_id).update(uname=new_name)
#         house = THouse.objects.filter(uid=user_name).update(uid=new_name)
#         request.session['uname'] = new_name
#         return redirect('/person')
#     return HttpResponse("修改名称失败")

def change_pwd(request):   #修改用户密码
    if request.method == 'GET':
        return render(request, 'change_pwdapp.html')
    else:
        uphone = request.POST['uphone']
        upassword = request.POST['upassword']
        new_password = request.POST['new_password']
        user = TUser.objects.filter(uphone=uphone).first()
    if user:
        # 判断密码是否正确
        upwd = TUser.objects.filter(uphone=uphone, upwd=upassword)
        if upwd:
            TUser.objects.filter(uphone=uphone, upwd=upassword).update(
                upwd=new_password)  ##如果用户名、原密码匹配则更新密码
            return HttpResponse("<h1 aligin='center'>修改密码成功</h1>"
                                        "<a href='/loginapp'>重新登录</a>")
        else:
            error = '请检查原密码是否输入正确'
            return render(request, 'change_pwdapp.html', {'error': error})
    else:
        error = '请检查手机号是否正确'
        return render(request, 'change_pwdapp.html', {'error': error})


def change_msg(request):    #修改用户基础信息
    new_name = request.GET.get('newName', '')
    uphone = request.GET.get('newPhone', '')
    usex = request.GET.get('newSex', '')
    uage = request.GET.get('newAge', '')
    uemail = request.GET.get('newEmail', '')
    user_id = request.session['id']
    user_name = request.session['uname']
    user = TUser.objects.filter(id=user_id).update(uname=new_name,uphone=uphone,
                                            usex=usex,uage=uage,uemail=uemail)
    if user:
        followuser = TFollow.objects.filter(uid=user_id).update(uname=new_name)
        house = THouse.objects.filter(uid=user_name).update(uid=new_name)
        comment = TComments.objects.filter(username=user_name).update(username=new_name)
        del request.session['uname']
        return HttpResponse("<h1 aligin='center'>修改用户信息成功，请退出并重新登录</h1>"
                            "<a href='/index'>跳转首页重新登录</a>")
    return HttpResponse("用户基础信息修改失败")


# def change_sex(request):    #修改用户性别
#     usex = request.GET.get('newSex', '')
#     user_id = request.session['id']
#     user = TUser.objects.filter(id=user_id).update(usex=usex)
#     if user:
#         return HttpResponse("性别修改成功")
#     return HttpResponse("性别修改失败")
#
#
# def change_age(request):   #修改用户年龄
#     uage = request.GET.get('newAge', '')
#     user_id = request.session['id']
#     user = TUser.objects.filter(id=user_id).update(uage=uage)
#     if user:
#         return HttpResponse("<h1 aligin='center'>年龄修改成功</h1>"
#                             "<a href='/userinfo'>跳转至个人中心</a>")
#     return HttpResponse("年龄修改失败")
#
#
# def change_email(request):   #修改用户邮箱
#     uemail = request.GET.get('newEmail', '')
#     user_id = request.session['id']
#     user = TUser.objects.filter(id=user_id).update(uemail=uemail)
#     if user:
#         return HttpResponse("<h1 aligin='center'>邮箱修改成功</h1>"
#                             "<a href='/userinfo'>跳转至个人中心</a>")
#     return HttpResponse("邮箱修改失败")


def change_header(request):  #修改用户头像
    if request.method == 'POST':
        pic = request.FILES['pic']
        save_path = '%s/avatars/%s'%(settings.MEDIA_ROOT,pic.name)
        with open(save_path,'wb') as f:
            for content in pic.chunks():
                f.write(content)
        user_id = request.session['id']
        TUser.objects.filter(id=user_id).update(header='avatars/%s'%pic.name)
    return HttpResponse("<h1 aligin='center'>修改头像成功</h1>"
                            "<a href='/userinfo'>查看头像</a>")


def get_house_type_api(request):  #首页获取房屋类型
    categories = TCategory.objects.all()
    data = serializers.serialize('json', categories)
    return HttpResponse(data)


# def search_more_api(request):   #房屋详情
#     house_name = request.GET['houseName']
#     house = THouse.objects.filter(hname=house_name).first()
#     user = TUser.objects.filter(uname=house.uid).first()
#     if request.session.get('uname', ''):
#         uname = request.session['uname']
#         return render(request, 'house.html', locals())
#     return render(request, 'house.html', locals())


def search_more_api(request):   #房屋详情
    house_name = request.GET['houseName']
    house = THouse.objects.filter(hname=house_name).first()
    user = TUser.objects.filter(uname=house.uid).first()
    comments_list = TComments.objects.filter(hname=house_name)
    if request.session.get('uname', ''):
        uname = request.session['uname']
        if request.method == 'GET':
             comments_list = TComments.objects.filter(hname=house_name)
        return render(request, 'house.html', locals())
    return render(request, 'house.html', locals())


def comments(request):  #评论
    uname = request.session['uname']
    hname = request.POST['hname']
    house = request.POST.get('hname')
    if request.method == 'POST':
        comment = request.POST.get('mycomment')
        if comment == '':
            pass
        else:
            TComments.objects.create(username=uname, hname=hname, comment=comment)
            # myurls = reverse('searchMore')
            return HttpResponseRedirect('/index')


def attention_house_api(request):   #收藏房源
    house_name = request.GET['houseName']
    if request.session.get('uname', ''):
        uid = request.session['id']
        uname = request.session['uname']
        have = TFollow.objects.filter(uid=uid)
        if have:  #如果存在收藏数据，则更新收藏
            TFollow.objects.filter(uid=uid).update(hname=house_name)
        else:   #如果不存在收藏数据，则创建收藏
            TFollow.objects.create(uid=uid,uname=uname,hname=house_name)
        data = {
            'message': '收藏房源成功'
        }
        return HttpResponse(json.dumps(data))
    data = {
        'message': '收藏房源失败，请先登陆'
    }
    return HttpResponse(json.dumps(data))

def followhouse_view(request):   #展示收藏房源数据
    uname = request.session['uname']
    uid = request.session['id']
    tenant = TFollow.objects.filter(uid=uid).first()
    return render(request, 'followhouse.html', locals())

def myhouse_view(request):   #展示发布房源数据
    uname = request.session['uname']
    uid = request.session['id']
    user = TUser.objects.filter(id=uid)
    Urole = user.filter(role='1')  # 设置访问权限，当用户角色为房东时
    house = THouse.objects.filter(uid=uname).all()
    return render(request, 'myhouse.html', locals())

def delfollow_view(request):   #取消收藏
    uid = request.session['id']
    delfollow = TFollow.objects.filter(uid=uid).delete()
    return render(request, 'followhouse.html', locals())


def order_house_api(request):     #验证用户是否登录
    if request.session.get('uname', ''):
        uname = request.session['uname']
        TUser.objects.filter(uname=uname)
        data = {
            'code': 1,
        }
        return HttpResponse(json.dumps(data))
    data = {
        'code': 2,
        'message': '租赁失败，请先登录'
    }
    return HttpResponse(json.dumps(data))

def order_house_html_api(request):    #租赁房屋权限识别
    house_name = request.GET['houseName']
    if request.session.get('uname', ''):
        uname = request.session['uname']  # 租户
        house = THouse.objects.filter(hname=house_name).first()
        landlord = house.uid  # 房东
        landlord = TUser.objects.filter(uname=landlord).first()
        user = TUser.objects.filter(uname=uname)
        Urole = user.filter(role='2') # 设置访问权限，当用户角色为租户时
        if Urole:
            return render(request, 'orderHouse.html', locals())
        else:
            return HttpResponse("<h1 aligin='center'>你当前的用户角色为房东，"
                                "无租赁房屋权限</h1><a href='/index.html'>返回首页</a>")

def generate_contract_api(request):    #租赁房屋生成合同数据
    start_times = request.GET['start_time']
    end_times = request.GET['end_time']
    price = request.GET['price']
    hname = request.GET['hname']
    tphone = request.GET['tphone']
    lphone = request.GET['lphone']
    landlord = request.GET['lname']
    landlord = TUser.objects.filter(uname=landlord).first()
    tid = request.session.get('id', '')
    exist = TContract.objects.filter(hname=hname).first()
    if exist:   #判断是否已出租
        starttime = TContract.objects.filter(hname=hname).values_list('start_time', flat=True)
        endtime =TContract.objects.filter(hname=hname).values_list('end_time', flat=True)
        gg = []
        hh = []
        for x in starttime:
            gg.append(x)
            for z in gg:
                start = z
        for i in endtime:
            hh.append(i)
            for j in hh:
                end = j
        print(start)
        print(end)
        b = datetime.strptime(start_times, '%Y-%m-%d')
        c = datetime.strptime(end_times, '%Y-%m-%d')
        poststarts = b.date() #用户输入的开始日期
        postends = c.date() #用户输入的结束日期
        if start<=poststarts<=end or start<=postends<=end:  #判断租期是否冲突
            data = {
                'code': 2,
                'message': '该房屋本时段已被出租，请返回返回重新租赁'
            }
            return HttpResponse(json.dumps(data))
        if poststarts <= start and postends >= end:
            data = {
                'code': 2,
                'message': '该房屋本时段已被出租，请返回返回重新租赁'
            }
            return HttpResponse(json.dumps(data))
        if poststarts <= start and start <= postends <= end:
            data = {
                'code': 2,
                'message': '该房屋本时段已被出租，请返回返回重新租赁'
            }
            return HttpResponse(json.dumps(data))
        if start<= poststarts <= end and postends >= end:
            data = {
                'code': 2,
                'message': '该房屋本时段已被出租，请返回返回重新租赁'
            }
            return HttpResponse(json.dumps(data))
        else:
            TContract.objects.create(start_time=start_times, end_time=end_times, price=price, hname=hname,
                                     lid=landlord.id, lphone=lphone, tphone=tphone, tid=tid)
            data = {
                'code': 1,
                'message': '租赁成功, 正在跳转，请稍等'
            }
            return HttpResponse(json.dumps(data))
    else:
        TContract.objects.create(start_time=start_times, end_time=end_times, price=price, hname=hname,
                    lid=landlord.id,lphone=lphone, tphone=tphone, tid=tid)
        data = {
            'code': 1,
            'message': '租赁成功, 正在跳转，请稍等'
        }
        return HttpResponse(json.dumps(data))


